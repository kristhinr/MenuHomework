#include<stdio.h>
int main(void){
	int abcd,ab,cd,i;
	i=0;
	
	for(abcd=1000;abcd<9999;abcd++){
		ab = abcd/100;
		cd = abcd%100;
		if(abcd == (ab+cd)*(ab+cd))
			printf("%-6d",abcd),i++;
	}
	printf("\n����%d��\n",i);
	return 0; 
}
