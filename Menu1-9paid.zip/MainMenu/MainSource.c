#include<stdio.h>
#include<stdlib.h> 

void faction_unit_number(int unit_number);
void faction_main_menu();
void faction_homework(int unit_number,int exercise_number);
//Level.3 ѡ����Ŀ 
void faction_homework(int unit_number,int exercise_number){
	int num; 
	system("cls");
	while(1){
		int count_number;
		printf("%d-%d\n",unit_number,exercise_number);
		count_number = unit_number*100 + exercise_number;
		printf("******************************\n");
		printf("1.Run the code.\n");
		printf("2.Display the source code.\n");
		printf("3.Return parent level.\n");
		printf("4.Exit the program.\n");
		printf("******************************\n");
		printf("Please input the number:\n");
		getchar(); 
		scanf("%d",&num);
		switch(num){
			case 1: 
				switch(count_number){
					case 101:system("1_1.exe");system("timeout /t -1");system("cls");break;
					case 102:system("1_2.exe");system("timeout /t -1");system("cls");break;
					
					case 201:system("2_1.exe");system("timeout /t -1");system("cls");break;
					case 202:system("2_2.exe");system("timeout /t -1");system("cls");break;
					case 203:system("2_3.exe");system("timeout /t -1");system("cls");break;
					case 204:system("2_4.exe");system("timeout /t -1");system("cls");break;
					
					case 301:system("3_1.exe");system("timeout /t -1");system("cls");break;
					case 302:system("3_2.exe");system("timeout /t -1");system("cls");break;
					case 303:system("3_3.exe");system("timeout /t -1");system("cls");break;
					case 304:system("3_4.exe");system("timeout /t -1");system("cls");break;
					case 305:system("3_5.exe");system("timeout /t -1");system("cls");break;
					case 306:system("3_6.exe");system("timeout /t -1");system("cls");break;
					
					case 401:system("4_1.exe");system("timeout /t -1");system("cls");break;
					case 402:system("4_2.exe");system("timeout /t -1");system("cls");break;
					case 403:system("4_3.exe");system("timeout /t -1");system("cls");break;
					case 404:system("4_4.exe");system("timeout /t -1");system("cls");break;
					case 405:system("4_5.exe");system("timeout /t -1");system("cls");break;
					
					case 501:system("5_1.exe");system("timeout /t -1");system("cls");break;
					case 502:system("5_2.exe");system("timeout /t -1");system("cls");break;
					case 503:system("5_3.exe");system("timeout /t -1");system("cls");break;
					case 504:system("5_4.exe");system("timeout /t -1");system("cls");break;
					
					case 601:system("6_1.exe");system("timeout /t -1");system("cls");break;
					case 602:system("6_2.exe");system("timeout /t -1");system("cls");break;
					case 603:system("6_3.exe");system("timeout /t -1");system("cls");break;
					case 604:system("6_4.exe");system("timeout /t -1");system("cls");break;
					case 605:system("6_5.exe");system("timeout /t -1");system("cls");break;
					case 606:system("6_6.exe");system("timeout /t -1");system("cls");break;
					case 607:system("6_7.exe");system("timeout /t -1");system("cls");break;
					case 608:system("6_8.exe");system("timeout /t -1");system("cls");break;
					
					case 701:system("7_1.exe");system("timeout /t -1");system("cls");break;
					case 702:system("7_2.exe");system("timeout /t -1");system("cls");break;
					case 703:system("7_3.exe");system("timeout /t -1");system("cls");break;
					case 704:system("7_4.exe");system("timeout /t -1");system("cls");break;
					case 705:system("7_5.exe");system("timeout /t -1");system("cls");break;
					case 706:system("7_6.exe");system("timeout /t -1");system("cls");break;
					case 707:system("7_7.exe");system("timeout /t -1");system("cls");break;
					case 708:system("7_8.exe");system("timeout /t -1");system("cls");break;
					
					case 801:system("8_1.exe");system("timeout /t -1");system("cls");break;
					case 802:system("8_2.exe");system("timeout /t -1");system("cls");break;
					case 803:system("8_3.exe");system("timeout /t -1");system("cls");break;
					case 804:system("8_4.exe");system("timeout /t -1");system("cls");break;
					case 805:system("8_5.exe");system("timeout /t -1");system("cls");break;
					case 806:system("8_6.exe");system("timeout /t -1");system("cls");break;
					case 807:system("8_7.exe");system("timeout /t -1");system("cls");break;
					case 808:system("8_8.exe");system("timeout /t -1");system("cls");break;
					
					case 901:system("9_1.exe");system("timeout /t -1");system("cls");break;
					case 902:system("9_2.exe");system("timeout /t -1");system("cls");break;
					case 903:system("9_3.exe");system("timeout /t -1");system("cls");break;
					case 904:system("9_4.exe");system("timeout /t -1");system("cls");break;
					
					case 1001:system("10_1.exe");system("timeout /t -1");system("cls");break;
					case 1002:system("10_2.exe");system("timeout /t -1");system("cls");break;
					case 1003:system("10_3.exe");system("timeout /t -1");system("cls");break;
					case 1004:system("10_4.exe");system("timeout /t -1");system("cls");break;
					case 1005:system("10_5.exe");system("timeout /t -1");system("cls");break;
					case 1006:system("10_6.exe");system("timeout /t -1");system("cls");break;
					
					case 1101:system("11_1.exe");system("timeout /t -1");system("cls");break;
					case 1102:system("11_2.exe");system("timeout /t -1");system("cls");break;
					case 1103:system("11_3.exe");system("timeout /t -1");system("cls");break;
					case 1104:system("11_4.exe");system("timeout /t -1");system("cls");break;
					
					case 1201:system("12_1.exe");system("timeout /t -1");system("cls");break;
					case 1202:system("12_2.exe");system("timeout /t -1");system("cls");break;
					case 1203:system("12_3.exe");system("timeout /t -1");system("cls");break;
					case 1204:system("12_4.exe");system("timeout /t -1");system("cls");break;
					
					case 1301:system("13_1.exe");system("timeout /t -1");system("cls");break;
					case 1302:system("13_2.exe");system("timeout /t -1");system("cls");break;
					case 1303:system("13_3.exe");system("timeout /t -1");system("cls");break;
					
					default:printf("Ŀ�겻���ڣ��������ء�");system("timeout /t 3");
						faction_unit_number(unit_number);getchar();break;
				};break;
			case 2:
				switch(count_number){	
					case 101:system("type 1_1.c");system("timeout /t -1");system("cls");break;
					case 102:system("type 1_2.cpp");system("timeout /t -1");system("cls");break;
					
					case 201:system("type 2_1.c");system("timeout /t -1");system("cls");break;
					case 202:system("type 2_2.c");system("timeout /t -1");system("cls");break;
					case 203:system("type 2_3.c");system("timeout /t -1");system("cls");break;
					case 204:system("type 2_4.c");system("timeout /t -1");system("cls");break;
					
					case 301:system("type 3_1.c");system("timeout /t -1");system("cls");break;
					case 302:system("type 3_2.c");system("timeout /t -1");system("cls");break;
					case 303:system("type 3_3.c");system("timeout /t -1");system("cls");break;
					case 304:system("type 3_4.c");system("timeout /t -1");system("cls");break;
					case 305:system("type 3_5.c");system("timeout /t -1");system("cls");break;
					case 306:system("type 3_6.c");system("timeout /t -1");system("cls");break;
					
					case 401:system("type 4_1.c");system("timeout /t -1");system("cls");break;
					case 402:system("type 4_2.c");system("timeout /t -1");system("cls");break;
					case 403:system("type 4_3.c");system("timeout /t -1");system("cls");break;
					case 404:system("type 4_4.c");system("timeout /t -1");system("cls");break;
					case 405:system("type 4_5.c");system("timeout /t -1");system("cls");break;
					
					case 501:system("type 5_1.c");system("timeout /t -1");system("cls");break;
					case 502:system("type 5_2.c");system("timeout /t -1");system("cls");break;
					case 503:system("type 5_3.c");system("timeout /t -1");system("cls");break;
					case 504:system("type 5_4.c");system("timeout /t -1");system("cls");break;
					
					case 601:system("type 6_1.c");system("timeout /t -1");system("cls");break;
					case 602:system("type 6_2.c");system("timeout /t -1");system("cls");break;
					case 603:system("type 6_3.c");system("timeout /t -1");system("cls");break;
					case 604:system("type 6_4.c");system("timeout /t -1");system("cls");break;
					case 605:system("type 6_5.c");system("timeout /t -1");system("cls");break;
					case 606:system("type 6_6.c");system("timeout /t -1");system("cls");break;
					case 607:system("type 6_7.c");system("timeout /t -1");system("cls");break;
					case 608:system("type 6_8.c");system("timeout /t -1");system("cls");break;
					
					case 701:system("type 7_1.c");system("timeout /t -1");system("cls");break;
					case 702:system("type 7_2.c");system("timeout /t -1");system("cls");break;
					case 703:system("type 7_3.c");system("timeout /t -1");system("cls");break;
					case 704:system("type 7_4.c");system("timeout /t -1");system("cls");break;
					case 705:system("type 7_5.c");system("timeout /t -1");system("cls");break;
					case 706:system("type 7_6.c");system("timeout /t -1");system("cls");break;
					case 707:system("type 7_7.c");system("timeout /t -1");system("cls");break;
					case 708:system("type 7_8.c");system("timeout /t -1");system("cls");break;
					
					case 801:system("type 8_1.c");system("timeout /t -1");system("cls");break;
					case 802:system("type 8_2.c");system("timeout /t -1");system("cls");break;
					case 803:system("type 8_3.c");system("timeout /t -1");system("cls");break;
					case 804:system("type 8_4.c");system("timeout /t -1");system("cls");break;
					case 805:system("type 8_5.c");system("timeout /t -1");system("cls");break;
					case 806:system("type 8_6.c");system("timeout /t -1");system("cls");break;
					case 807:system("type 8_7.c");system("timeout /t -1");system("cls");break;
					case 808:system("type 8_8.c");system("timeout /t -1");system("cls");break;
					
					case 901:system("type 9_1.c");system("timeout /t -1");system("cls");break;
					case 902:system("type 9_2.c");system("timeout /t -1");system("cls");break;
					case 903:system("type 9_3.c");system("timeout /t -1");system("cls");break;
					case 904:system("type 9_4.c");system("timeout /t -1");system("cls");break;
					
					case 1001:system("type 10_1.c");system("timeout /t -1");system("cls");break;
					case 1002:system("type 10_2.c");system("timeout /t -1");system("cls");break;
					case 1003:system("type 10_3.c");system("timeout /t -1");system("cls");break;
					case 1004:system("type 10_4.c");system("timeout /t -1");system("cls");break;
					case 1005:system("type 10_5.c");system("timeout /t -1");system("cls");break;
					case 1006:system("type 10_6.c");system("timeout /t -1");system("cls");break;
					
					case 1101:system("type 11_1.c");system("timeout /t -1");system("cls");break;
					case 1102:system("type 11_2.c");system("timeout /t -1");system("cls");break;
					case 1103:system("type 11_3.c");system("timeout /t -1");system("cls");break;
					case 1104:system("type 11_4.c");system("timeout /t -1");system("cls");break;
					
					case 1201:system("type 12_1.c");system("timeout /t -1");system("cls");break;
					case 1202:system("type 12_2.c");system("timeout /t -1");system("cls");break;
					case 1203:system("type 12_3.c");system("timeout /t -1");system("cls");break;
					case 1204:system("type 12_4.c");system("timeout /t -1");system("cls");break;
					
					case 1301:system("type 13_1.c");system("timeout /t -1");system("cls");break;
					case 1302:system("type 13_2.c");system("timeout /t -1");system("cls");break;
					case 1303:system("type 13_3.c");system("timeout /t -1");system("cls");break;
					
					default:printf("Ŀ�겻���ڣ��������ء�");system("timeout /t 3");
						faction_unit_number(unit_number);break;
				}break;
			case 3:system("cls");faction_unit_number(unit_number);getchar();break;
			case 4:exit(0);break;
		}
	}
}
//Level.1 ���˵�-ѡ���½�  
void faction_main_menu(){
	int unit_number;
	int exercise_number;
	system("cls");
	while(1){
		printf("\n");
		printf("******************************\n");
		printf("ѡ���½ڣ�\n");
		printf("1-2-3-4-5-6-7-8-9-19-11-12-13 \n");
		printf("\n");
		printf("����'-1'�˳���\n");
		printf("******************************\n");
		printf("Please input the number:\n");
		scanf("%d",&unit_number);
		if(unit_number == -1){
			exit(0);break;
		}
		else if(unit_number >=1 && unit_number <=13){
			faction_unit_number(unit_number);break;
		}
		else{
			system("cls");printf("��%d�½ڲ����ڡ�",unit_number);
			getchar();
		}
	} 
}
//Level.2 �����˵�-ѡ��С�� 
void faction_unit_number(int unit_number){
	int exercise_number;
	system("cls");
	while(1){
		printf("��%d��\n",unit_number);
		printf("******************************\n");
		printf("ѡ����Ŀ��\n");
		switch(unit_number){
			case 1:printf("1-2 \n");break;
			case 2:
			case 5:
			case 9:
			case 11:
			case 12:printf("1-2-3-4 \n");break;
			case 3:
			case 10:printf("1-2-3-4-5-6 \n");break;
			case 4:printf("1-2-3-4-5 \n");break;
			case 13:printf("1-2-3 \n");break;
			default:printf("1-2-3-4-5-6-7-8 \n");break;
		}
		printf("��'9'�������˵���\n");	
		printf("����'-1'�˳���\n");
		printf("******************************\n");
		printf("Please input the number:\n");
		getchar();
		scanf("%d",&exercise_number);
		if(exercise_number >= 100 || exercise_number < -1){
			printf("Ŀ�겻���ڡ�");system("timeout /t 3"); 
			faction_unit_number(unit_number);break;
		} 
		if(exercise_number == 9){
			faction_main_menu();getchar();break;
		}
		else if(exercise_number == -1){
			exit(0);break;
		}
		else{
			faction_homework(unit_number,exercise_number);
			getchar(); 
		}
	}
}

void main(){
	system("PrintName.exe");//������ļ������κη�ʽ��ӡ���������Ϊչʾ 
	system("timeout /t -1"); 
	faction_main_menu(); 
} 

