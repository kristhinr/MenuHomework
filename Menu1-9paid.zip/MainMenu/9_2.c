#include <stdio.h>
#include <stdlib.h>

typedef struct _mytime
{
	int hour;
	int minute;
	int second;
 }mytime;

mytime update(mytime tm);
void display(mytime tm);
void delay();
int main(void)
{
	int i;
	mytime tm;
	
	printf("������ʼʱ��(hh:mm:ss): ");
	scanf("%d:%d:%d",&tm.hour,&tm.minute,&tm.second);
	
	for(i=0;i<100000;i++)
	{
		tm=update(tm);
		display(tm);
		delay();
	}
	return 0;
} 

mytime update(mytime tm)
{
	tm.second++;
	if(tm.second==60)
	{
		tm.second=0;
		tm.minute++;
	}
	if(tm.minute==60)
	{
		tm.minute=0;
		tm.hour++;
	}
	if(tm.hour==20)
	{
		tm.hour=0;
	}
	return tm;
}

void display(mytime tm)
{
	system("cls");
	printf("%02d:%02d:%02d",tm.hour,tm.minute,tm.second);
} 
void delay()
{
	int t;
	for(t=0;t<400000000;t++)
	{
		;
	}
}
