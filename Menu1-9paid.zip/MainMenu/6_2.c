#include<stdio.h>
int main(void){
	int a,i;
	i=0;
	for(a=1;a<=999;a++){
		if(a%3 == 0 && (a%10==5 || a/10%10==5 || a/100==5))		
			printf("%5d",a),i++;
	}
	printf("\n����%d��\n",i);	

}
