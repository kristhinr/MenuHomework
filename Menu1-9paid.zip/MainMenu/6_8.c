#include<stdio.h>
int main(void){
	int n,m,m1,q,sum=0;
	printf("����nֵ��");
	scanf("%d",&n); 
	printf("����Ľ��У�");
	for(m=1;m<n;m++){
		if(m>1)
			printf("%d  ",m-1);
		for(m1=m,q=1;m1>0;m1--){
			q = q*m1; 
		}
		sum += q;
		if(sum >= n)
			break;
	}
	printf("\n");
	
	return 0; 
}
