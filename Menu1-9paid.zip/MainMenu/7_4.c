#include<stdio.h>
int Getgys(int a, int b){
	int temp;
	if(a<b){
		temp = a; a = b; b = temp;}
	while(b != 0){
		temp = a%b; a = b; b = temp;}
	return a;
}
int Getgbs(int a, int b){
	return a*b/Getgys(a,b);
}
int main(){
	int a,b;
	printf("Input 2 numbers:");
	scanf("%d%d",&a,&b);
	printf("��С������%d,�������%d\n",Getgbs(a,b),Getgys(a,b));
	return 0;
} 
