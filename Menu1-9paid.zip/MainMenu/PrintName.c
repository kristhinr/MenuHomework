#include<stdio.h>
//������ļ������κη�ʽ��ӡ���������Ϊչʾ 
int main() {
	int x = 0;
	for (x = 0; x < 30; x++) {
		if (x == 5 || x == 15 || x == 26 || x == 28)
			printf("*");
		else
			printf(" ");
	}printf("\n");//line1
	for (x = 0; x < 30; x++) {
		if (x >= 1 && x <= 9|| x >= 15 && x<=17 || x== 22 || x == 26 || x == 29)
			printf("*");
		else
			printf(" ");
	}printf("\n");//line2
	for (x = 0; x < 30; x++) {
		if (x == 3 ||x == 5 || x == 7 || x == 15 || x >= 22 && x <= 29)
			printf("*");
		else
			printf(" ");
	}printf("\n");//line3
	for (x = 0; x < 30; x++) {
		if (x == 2 || x == 5 || x == 8 || x >= 12 && x <=18 || x >= 22 || x == 24 || x == 26 ||x == 27)
			printf("*");
		else
			printf(" ");
	}printf("\n");//line4
	for (x = 0; x < 30; x++) {
		if (x >= 3 && x <= 7 || x >= 12 && x <= 16 ||x == 18 || x >= 21 && x <= 23|| x >= 26 && x <= 28)
			printf("*");
		else
			printf(" ");
	}printf("\n");//line5
	for (x = 0; x < 30; x++) {
		if (x == 5 || x == 6 || x >= 12 && x <= 18 || x == 21 || x == 23 || x == 25 || x == 28 || x == 29)
			printf("*");
		else
			printf(" ");
	}printf("\n");//line6
	for (x = 0; x < 30; x++) {
		if (x >= 1 && x <= 9 || x >= 11 && x <= 19)
			printf("*");
		else
			printf(" ");
	}printf("\n");//line7
	for (x = 0; x < 30; x++) {
		if (x == 5 || x == 15 || x == 21 || x == 23 || x == 25 || x == 28 || x == 29)
			printf("*");
		else
			printf(" ");
	}printf("\n");//line8
	for (x = 0; x < 30; x++) {
		if (x == 4 || x == 5 || x == 15 || x == 21 || x == 23 || x == 26 || x == 29)
			printf("*");
		else
			printf(" ");
	}printf("\n");//line9
	return 0;
}
