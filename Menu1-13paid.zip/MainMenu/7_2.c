#include<stdio.h>
int main(void){
	printf("����Ϊ��\n");
	printf("scanf(\"%%d:%%d:%%d\",&hour,&minute,&secomd);\n");
	printf("second = 0;\n");
	printf("if(minute == 60)\n");
	printf("hour = 0;\n");
	printf("printf(\"%%02d:%%02d:%%02d\",hour,minute,second);\n");
	return 0; 
}
