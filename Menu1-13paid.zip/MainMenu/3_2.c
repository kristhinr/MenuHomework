#include<stdio.h>
int main(void){
	printf("    16/      10/ \n");
	printf("    FA      250  \n");
	printf("    5B       91  \n");
	printf("  1234     4660  \n");
	printf("  FFFE    65534  \n");
	return 0;
} 
