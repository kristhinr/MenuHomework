#include<stdio.h>
int main(void){
	int m,fm,k,i;
	i=0;
	for(k=0;k<36;k=k+2){
		for(m=0;m<36;m++){
			for(fm=0;fm<36;fm++){
				if(m+fm+k == 36 && 4*m+3*fm+k/2==36)
					printf("��%d Ů%d С��%d\n",m,fm,k),i++;
			}
		}
	}
	printf("����%d���\n",i);
	return 0; 
}
