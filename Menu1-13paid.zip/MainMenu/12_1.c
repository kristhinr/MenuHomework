#include <stdio.h>
#include <malloc.h>
struct node
{
	int data;
	struct node *next;
};

typedef struct node funode;

void funcna(funode *h, int m);
funode *Create(int n);

int main(void)
{
	funode *h;
	int n, m;
	printf("����������: ");
	scanf("%d", &n);
	printf("����m: ");
	scanf("%d", &m);
	h = Create(n);
	funcna(h, m);
}
void funcna(funode *h, int m)
{
	funode *p=h, *q; 
	int j;
	while (p->next!=p) //��ֻһ�����
	{
		for(j=1;j<m- 1;j++)
		{
			p= p->next;
		}
		q= p->next;
		p->next = q->next;
		printf("%d, ", q->data);
		free(q);
		p= p->next;
	} 
	printf("%d\n", p->data);
}
funode *Create(int n) //�� ��ѭ������
{
	funode *s, *r, *h;
	int i;
	for(i= 1;i<=n;i++)
	{
		s = (funode *)malloc(sizeof(funode));
		s->data= i;
		s->next = NULL;
		if(i==1)
		{ 
			r=h=s;
		}
		else
		{ 
			r->next= s;
		} 
		r= s;
	}
	r->next= h;//���Ľ��ָ���һ��
	return h;
} 
 
 
