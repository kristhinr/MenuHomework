#include<stdio.h>
int main(void){
	int yy,mm,dd,dds,day;
	day = 0;
	dds = 28;
	printf("����һ������ �� �� �գ�");
	scanf("%d%d%d",&yy,&mm,&dd);
	if(mm != 2 && dd == 29 || mm > 12 || mm < 1|| dd > 31 || dd < 1 || yy < 1)
		printf("�����ڲ��Ϸ���\n");
	else{
		if(yy%4 == 0 && yy%100 !=0 || yy%400 ==0)
			dds = 29;
//	31-  -31-30-31-30-31-31-30-31-30-31
		switch(mm){
			case 12:day = day+30;
			case 11:day = day+31;
			case 10:day = day+30;
			case  9:day = day+31;
			case  8:day = day+30;
			case  7:day = day+31;
			case  6:day = day+31;
			case  5:day = day+30;
			case  4:day = day+31;
			case  3:day = day+dds;
			case  2:day = day+31;
			case  1:day = day;break;
		}
		printf("��������%d���%d�졣\n",yy,day+dd);
	}
	return 0;
}
