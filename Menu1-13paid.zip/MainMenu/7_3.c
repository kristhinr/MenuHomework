#include<stdio.h>
int Getmin(int a, int b,int c){
	int min;
	a=(a<b)?a:b;
	min=(a<c)?a:c;
	return min;
}

int main(){
	int a,b,c;
	printf("Input three numbers:");
	scanf("%d%d%d",&a,&b,&c);
	printf("Min=%d\n",Getmin(a,b,c));
	return 0;
} 
