# include<stdio.h>
void main()
{
	printf("\
(1) 16,10\n\
(2) 129,201\n\
(3) 12\n\ 
	");
 } 
