#include <stdio.h>
#include <stdlib.h>
#include <time.h>
typedef struct _node
{ 
	int number;
	int score;
	struct _node *next;
} node, *pnode;

pnode create(void);
void output(pnode head);
void merger( pnode heada, pnode headb);
void sort(pnode head);

int main()
{ 
	pnode heada, headb;
 
	srand((unsigned)time(NULL));

	heada = create();
	printf("aԭʼ����Ϊ: \n");
	output(heada);

	headb = create();
	printf("bԭʼ����Ϊ: \n");
	output(headb);

	merger(heada, headb);
	printf("�ϲ�������Ϊ: \n");	
	output(heada);
	sort(heada);
	printf("���������Ϊ: \n");
	output(heada);
	return 0;
}

pnode create(void)
{ 
	int i;
	int number;
	//����������
	pnode head = (pnode)malloc(sizeof(node));
	pnode p, q; 
	number = rand() % 20+ 1;
	
	head->next = NULL;
	p = head;
	for (i= 0;i < number; i++)
	{
		q = (pnode)malloc(sizeof(node));
		q->number = rand() % 1000;
		q->score = rand() % 100;
		q->next = p->next;
		p->next= q;
		p= p->next;
	}
	return head;
}

void output(pnode head)
{
	pnode p = head->next;
	while (p->next != NULL)
	{ 
		printf("%d->", p->number);
		p= p->next;
	} 
	printf("%d\n", p->number);
}

void merger(pnode heada, pnode headb)
{
	pnode p = heada;
	while (p->next != NULL)
	{
		p= p->next;
	}
	p->next = headb->next;
}

void sort(pnode head)
{
	pnode p,q,r;
	p = head->next;
	q= p->next;
	head->next = NULL;
	while (p != NULL)
	{
		r= head;
		while (r->next != NULL)
		{ 
			if (r->next->number > p->number)
			{
				p->next = r->next;
				r->next= p;
				break;
			} 
			r = r->next;
		} 
		if (r->next == NULL)
		{
			p->next = r->next;
			r->next= p; 
		}
		p=q;
		if(p == NULL)
		{
			break;
		}
		q = q->next;
	}
}






