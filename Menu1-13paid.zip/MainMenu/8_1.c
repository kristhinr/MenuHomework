#include<stdio.h>

int main(){
	printf("������:\n");
		printf("(1)5,6,7,8\n");
		printf("(2)20,21,22,23\n");
	return 0;
} 
