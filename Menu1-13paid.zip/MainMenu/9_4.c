#include <stdio.h>
#include <string.h>

typedef struct _singer
{
	char name[8];
	struct
	{
		int age;
		int vote;
	}result[3];
	int total_votes;
} singer;
void initialize(singer voc[],int singers);
void input(singer voc[],int singers,int voters);
void output(singer voc[],int singers);
void handle(char string[],singer voc[],int singers);

int main(void)
{
	singer vocalist[5]={{"deng"},{"han"},{"wei"},{"luo"},{"zhang"}};
	initialize(vocalist,5);
	input(vocalist,5,18);
	output(vocalist,5);
	return 0;
}

void initialize(singer voc[],int singers)
{
	int i,j;
	for(i=0;i<singers;i++)
	{
		for(j=0;j<3;j++)
		{
			voc[i].result[j].age=20+10*j;
			voc[i].result[j].vote=0;
		}
		voc[i].total_votes=0;
	}
}

void input(singer voc[],int singers,int voters)
{
	int i,j;
	char string[80];
	printf("�����������ѡ��1 ��ѡ��2��ʹ�ÿո�ָ�����\n");
	for(i=0;i<voters;i++)
	{
		gets(string);
		handle(string,voc,singers);
	}
	for(i=0;i<singers;i++)
	{
		for(j=0;j<3;j++)
		{
			voc[i].total_votes += voc[i].result[j].vote;
		}
	}
}

void output(singer voc[],int singers)
{
	int i,j;
	printf("����\t");
	for(i=0;i<singers;i++)
	{
		printf("%s\t",voc[i].name);
	}
	printf("\n");
	printf("��Ʊ��\t");
	for(i=0;i<singers;i++)
	{
		printf("%d\t",voc[i].total_votes);
	}
	printf("\n");
	for(i=0;i<3;i++)
	{
		printf("%d��\t",20+i*10);
		for(j=0;j<singers;j++)
		{
			printf("%d\t",voc[j].result[i].vote);
		}
		printf("\n");
	}
}
void handle(char string[],singer voc[],int singers)
{
	int i,j,k,next = 0;
	char temp[80];
	char cutout[80];
	char sin[2][8];//��ͶƱ���� 
	int age;
	
	strcpy(temp,string);
	//ȥ����ǰ��Ŀո� 
	for(i=next;temp[i]!='\0';i++)
	{
		if(temp[i]!= ' ')
		{
			next=i;
			break;
		}
	}
	for(i=next,j=0;temp[i]!='\0';i++)
	{
		if(temp[i]!=' ')
		{
			cutout[j]=temp[i];
			j++;
		}
		else
		{
			cutout[j]='\0';
			next=i;
			break;
		}
	}
	if(temp[i]=='\0')
	{
		cutout[j]='\0';
		next=i;
	}
	if(strcmp(cutout,"30")==0)
	{
		age=30;
	}
	else if(strcmp(cutout,"40")==0)
	{
		age=40;
	}
	else
	{
		return;//���䲻�Ϸ� 
	}
	for(k=0;k<2;k++)
	{
		//ȥ���ո� 
		for(i=next;temp[i]!='\0';i++)
		{
			if(temp[i] != ' ')
			{
				next=i;
				break;
			}
		}
		//��һ����
		for(i=next,j=0;temp[i]!='\0';i++)
		{
			if(temp[i]!=' ')
			{
				cutout[j]=temp[i];
				j++;
			}
			else
			{
				cutout[j]='\0';
				next=i;
				break;
			}
		} 
		if(temp[i]=='\0')
		{
			cutout[j]='\0';
			next=i;
		}
		for(i=0;i<singers;i++)
		{
			if(strcmp(cutout,voc[i].name)==0)
			{
				strcpy(sin[k],cutout);
				break;
			}
		} 
		if(i==singers)//���������� 
		{
			return;
		}
	}
	//�������Ƿ��зǿո��ַ���
	for(i=next;temp[i]!='\0';i++)
	{
		if(temp[i]!=' ')
		{
			return;
		}
	}
	//������Ʊ��Ͷ��ͬһ����
	if(strcpy(sin[0],sin[1])==0)
	{
		return;
	} 
	//���������ӵ���Ӧ����
	for(i=0;i<2;i++)
	{
		for(k=0;k<singers;k++)
		{
			if(strcmp(sin[i],voc[k].name)==0)
			{
				for(j=0;j<3;j++)
				{
					if(voc[k].result[j].age==age)
					{
						voc[k].result[j].vote++;
					}
				}
			}
		}
	} 
}











