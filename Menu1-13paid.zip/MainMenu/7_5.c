#include<stdio.h>
int Getsum(int a){
	int sum = 0;
	while(a>=10){
		sum = sum + a%10;
		a= a/10;
	}
	sum = sum + a;
	return sum;
}

int main(){
	int a;
	printf("Input a number:");
	scanf("%d",&a);
	printf("%d\n",Getsum(a));
	return 0;
} 
