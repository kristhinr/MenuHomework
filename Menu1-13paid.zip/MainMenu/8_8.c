#include<stdio.h>

int main(){
	int i,j,m,n;
	int temp;
	int a[100];
	for(i=0;i<100;i++){
		a[i]=i+1;
	}
	printf("����m,n:");
	scanf("%d%d",&m,&n);
	printf("ԭ����:\n");
	for(i=0;i<m+n;i++){ 
		printf("%d ",a[i]);
	} 
	for(i=0;i<m;i++){
		temp = a[0];
		for(j=0;j<m+n-1;j++){ 
			a[j]=a[j+1];
		} 
		a[j]=temp; 
	}
	printf("\n���Ϊ:\n");
	for(i=0;i<m+n;i++){ 
		printf("%d ",a[i]);
	} 
	return 0;
} 
