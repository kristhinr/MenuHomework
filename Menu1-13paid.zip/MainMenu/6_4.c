#include<stdio.h>
int main(void){
	int x,y;
	x=1;y=1; 
	for(x=1;x<10;x++){
		for(y=1;y<=x;y++){
			printf("%3d*%d=%-2d",x,y,x*y);
		}
		printf("\n");
	}
}
