#include<stdio.h>
int main(void){
	printf("    10/                     2/            16/  \n");
	printf("    12                   1100              C   \n");
	printf("    31                  11111             1F   \n");
	printf("   369              101110001            171   \n");
	printf(" 10000         10011100010000           2710   \n");
	return 0;
} 
