#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main(void)
{
	int i, number;
	FILE *fp;
	
	fp = fopen("number.dat", "wb");
	if (fp == NULL)
	{
		printf("�����ļ�����! \n");
		return 0;
	}
	srand((unsigned)time(NULL));
	for(i= 0;i< 500; )
	{ 
		number = rand() % 10000;
		if (number < 1000)
		{
			continue;
		}
		fwrite(&number, sizeof(number), 1, fp);
		i++;
	}
	fclose(fp);
	return 0;
}

