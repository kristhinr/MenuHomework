#include<stdio.h>
int isperfect(int number){
	int i;
	int sum=0;
	for(i=1;i<number;i++){
		if(number%i==0)
			sum+=i;
	}
	if(number==sum)
		return 1;
	else	
		return 0;
}

int main(){
	int i;
	for(i=1;i<10000;i++){
		if(isperfect(i)==1){
			printf("%d  ",i);
		}
	}
	printf("\n");
	return 0;
} 
