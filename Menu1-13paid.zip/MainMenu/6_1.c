#include<stdio.h>
int main(void){
	int a,i;
	i=0;
	for(a=10000;a<=30000;a++){
		if(a%3 == 0 && a%5 ==0 && a%7 ==0 && a%23 ==0)
			printf("%d ",a),i++;
	}
	printf("\n����%d��\n",i);	
}
