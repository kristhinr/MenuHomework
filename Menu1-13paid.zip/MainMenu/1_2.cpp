#include<stdio.h>
#include<graphics.h>
#include<conio.h>
int main(void){
	initgraph(500,400);
	circle(200,200,100);
	circle(300,200,100);
	circle(250,200,50);
	getch();
	closegraph(); 
	return 0; 
}
