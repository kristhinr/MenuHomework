#include<stdio.h>
int main(void){
	printf("�ؼ��֣�\n enum  union  struct\n");
	return 0;
} 
