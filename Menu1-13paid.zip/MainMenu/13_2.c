# include<stdio.h>
void main()
{
	printf("\
(1) x=x&0x0f\n\
(2) x=x|0x00ff\n\
(3) x=(-x)^0x0f\n\
(4) 5\n\
	");
 } 
