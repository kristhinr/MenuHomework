#include <stdio.h>
int main(int argc, char *argv[])
{
	char ch;
	FILE *fp;
	if (argc != 2)
	{
		printf("��ʹ�ø�ʽ:\n");
		printf("[cmdfile](11_1.exe)  <filename>(*.txt)\n");
		return 0;
	} 
	fp = fopen(argv[1], "r");
	if(fp == NULL)
	{ 
		printf("δ�ҵ��ļ�\n");
		return 0;
	}
	ch = fgetc(fp);
	while (!feof(fp))
	{
		putchar(ch);
		ch = fgetc(fp);
	} 
	fclose(fp);
	return 0;
} 

