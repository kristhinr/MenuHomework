#include <stdio.h>
int main(void)
{ 
	int i, j, k, cnt, number;
	int array[500];
	FILE *fp; 
	fp = fopen("number.dat", "rb");
	if(fp == NULL)
	{ 
		printf("���ļ�����! \n");
		return 0;
	}
	cnt= 0;
	for(i=0;i< 500; i++)
	{
		fread(&number, sizeof(number), 1, fp);
		if (number/ 1000 % 10 + number/ 100 % 10
			== number/ 10 % 10 + number % 10)
		{
		array[cnt++] = number;
		}
	}
	fclose(fp);
	for(i=0;i< cnt; i++)
	{
		for(j=i+ 1;j< cnt;j++)
		{
			k=i;
			if (array[k] > array[i])
			{ 
				k=j;
			}
			if(k!=i) 
			{
				array[i] = array[i] + array[k];
				array[k] = array[i] - array[k];
				array[i] = array[i] - array[k];
			}
		}
	}
	fp = fopen("sortmumber.txt", "w");
	if (fp == NULL)
	{ 
		printf("����д�ļ�����! \n"); 
		return 0;
	} 
	for(i= 0;i< cnt; i++)
	{	
		fprintf(fp, "%d ", array[i]);
	} 
	return 0;
}




