#include<stdio.h>
int main(void){
	printf("(1)1234\n");
	printf("(2)1  2  34\n");
	printf("(3)scanf(\"%%c,%%c,%%d\",&a,&b,&c);\n");
	printf("(4)'1',\"2\",\\34\\  \n");
	printf("(5)scanf(\"%%c%%*c%%c%%*c%%d\",&a,&b,&c);\n");
	return 0; 
}
