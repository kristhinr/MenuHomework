#include <stdio.h>
#include <string.h>
void main() 
{
	int i= 0, j, length;
	char ch;
	char str[1000];
	FILE *fp;
	fp= fopen("A.txt","r");
	if(fp == NULL)
	{
		printf("���ļ�A����! \n");
		return 0;
	} 
	ch = fgetc(fp);
	while (!feof(fp))
	{
		str[i++] = ch;
		ch = fgetc(fp);
	}
	fclose(fp);
	fp= fopen("B.txt","r");
	if(fp == NULL)
	{
		printf("���ļ�B����! \n");
		return 0;
	}
	ch = fgetc(fp);
	while (!feof(fp))
	{ 
		str[i++] = ch;
		ch = fgetc(fp);
	}
	fclose(fp);
	str[i]= '\0'; 
	length = strlen(str);
	for(i = 0;i< length; i++)
	{
		for(j=0;j< length-i-1;j++)
		{
			if (str[j] > str[j+1])
			{ 
				ch = str[j];
				str[j] = str[j+1];
				str[j+1] = ch; 
			}
		}
	} 
	fp= fopen("C.txt", "w");
	if (fp == NULL)
	{
		printf("���ļ�C����! \n");
		return 0;
	}
	fprintf(fp, "%s", str);
	fclose(fp);
	return 0;
}


