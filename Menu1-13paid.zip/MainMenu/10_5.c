#include <stdio.h>
#include <stdlib.h>
#include <time.h> 
#include <string.h>
typedef struct _card
{
	int face;//����
	int suit;//��ɫ
}card;
typedef struct _deal
{
	card cards;
	int person;
} deal;
typedef struct _person
{
	int person;
	card cards[13];
}person;
void initailize(card cards[], deal dealresult[]);
void dealing(deal dealresult[], person personnal[]);
void output(person personnal[]);
int main(void)
{
	card cards[52];
	deal dealresult[52];
	person personnal[4]={{1},{2},{3},{4}};
	initailize(cards,dealresult);
	dealing(dealresult,personnal);
	output(personnal);
	return 0;
}
void initailize(card cards[],deal dealresult[])
{
	int i,j;
	//����52����
	for(i=0;i<13;i++)
	{
		for(j=0;j<4;j++)
		{
			cards[i+13*j].face=i;
			cards[i+13*j].suit=j;
		}
	}
	for(i=0;i<52;i++)
	{
		dealresult[i].cards=cards[i];
	}
}
void dealing(deal dealresult[], person personnal[])
{
	int i,j;
	char tempperson[8]="1234";
	int temp[4]={0};
	int random;
	srand((unsigned)time(NULL));
	for(i=0;i<52;i++)
	{
		random=rand()%strlen(tempperson);
		dealresult[i].person=tempperson[random]-49;
		personnal[tempperson[random]-49].cards[temp[random]]=dealresult[i].cards;
		temp[random]++;
		if(temp[random]==13)
		{
			for(j=random;(unsigned)j<strlen(tempperson)-1;j++)
			{
				temp[j]=temp[j+1];
				tempperson[j]=tempperson[j+1];
			}
			tempperson[j]=tempperson[j+1];
		}
		;
	}
}
		
void output(person personnal[])
{
	int i,j;
	char suit[8]={0x53,0x48,0x44,0x43};
	char face[16]="A234567890JQK";
	
	for(i=0;i<4;i++)
	{
		printf("Player%d��",i+1);
		for(j=0;j<13;j++)
		{
			printf("%c",suit[personnal[i].cards[j].suit]);//suit
			if(face[personnal[i].cards[j].face]!='0')
			{
				printf("%c  ",face[personnal[i].cards[j].face]);//face
			}
			else
			{
				printf("10 ");
			}
			
		}
		printf("\n");
	}
	printf("\nS-Spades  H-Hearts  C-Clubs  D-Diamonds\n");
}








