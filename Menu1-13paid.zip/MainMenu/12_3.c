#include <stdio.h>
#include <stdlib.h>
#include <time.h>
typedef struct _node
{ 
	int number;
	int score;
	struct _node *next;
} node, *pnode;

pnode create(void);
void output(pnode head);
void merger( pnode heada, pnode headb);
void sort(pnode head);

int main()
{ 
	pnode heada, headb;
 
	srand((unsigned)time(NULL));

	heada = create();
	printf("aԭʼ����Ϊ: \n");
	output(heada);

	headb = create();
	printf("bԭʼ����Ϊ: \n");
	output(headb);

	wipeoff(heada, headb);
	printf("aɾ��b�д��ڵ����ݺ�����Ϊ: \n");	
	output(heada);
	return 0;
}

pnode create(void)
{ 
	int i;
	int number;
	pnode head = (pnode)malloc(sizeof(node));
	pnode p, q; 
	
	number = rand() % 20+ 1;	
//	printf("��������������: ");
//	scanf("%d", &number);
	head->next = NULL;
	p = head;
	for(i= 0;i < number; i++)
	{ 
		q = (pnode)malloc(sizeof(node));
		q->number = rand() % 100;
	//	scanf("%d", &q->number);
			
		q->next = p->next;
		p->next = q;
		p = p->next;
	}
	return head;
} 

void output(pnode head)
{
	pnode p = head->next;
	
	while (p->next != NULL)
	{ 
		printf("%d->", p->number);
		p= p->next;
	} 
	printf("%d\n", p->number);
}

void wipeoff(pnode heada, pnode headb)
{
	pnode p, q, r;
	p = heada;
	
	while (p->next != NULL)
	{ 
		r = headb->next;
		while (r != NULL)
		{ 
			if (p->next->number == r->number)
			{ 
				q = p->next;
				p->next = q->next;
				free(q);
				break;
			}
			r = r->next;
		}
		if (r != NULL)
		{
			continue;
		} 
		p= p->next;
	} 
}

