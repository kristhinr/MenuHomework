#include <stdio.h>
#include <string.h>

typedef struct _ballot
{
	char name[8];
	int vote;
 } ballot;

void input(ballot can[4]);
void output(ballot can[4]);

int main(void)
{
	ballot candidate[4]=
	{
		{"zhao",0},
		{"qian",0},
		{"sun",0},
		{"li",0}
	};
	
	input(candidate);
	output(candidate);
	return 0;
}

void input(ballot can[4])
{
	int i,j;
	char name[8];
	printf("�����ѡ�����֣�\n");
	for(i=0;i<20;i++)
	{
		gets(name);
		for(j=0;j<4;j++)
		{
			if(strcmp(name,can[j].name)==0)
			{
				can[j].vote++;
			}
		}
	}
}
void output(ballot can[4])
{
	int i;
	printf("����\tzhao\tqian\tsun\tli\n");
	printf("��Ʊ��\t");
	for(i=0;i<4;i++)
	{
		printf("%d\t",can[i].vote);
	}
	printf("\n");
}

