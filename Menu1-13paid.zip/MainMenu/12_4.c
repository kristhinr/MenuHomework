#include <stdio.h>
#include <stdlib.h>
typedef struct _node
{
	int data;
	struct _node *next;
} node, *pnode;
pnode create(void);
void output(pnode head);
void inverse(pnode head);
int main()
{ 
	pnode head;
	head = create();
	output(head);
	inverse(head);
	output(head);
	return 0;
}
pnode create(void)
{
	int i;
	int a[]={2,7,9, 8, 3, 0};//ʹ�������ʼ����������0����������0����������
	
	pnode head = (pnode)malloc(sizeof(node));
	pnode p, q;

	head->next = NULL; 
	p = head;
	for(i= 0; a[i]!=0;i++)
	{
		q = (pnode)malloc(sizeof(node));
		q->data = a[i];
		q->next = p->next;
		p->next= q;
		p= p->next;
	}
	return head;
} 
void output(pnode head)
{ 
	pnode p = head->next;
	while (p != NULL)
	{
		printf("%d ", p->data);
		p= p->next;
	} 
	printf("\n");
} 

void inverse(pnode head)
{ 
	pnode p, q;
	p = head->next;
	q = p->next;
	head->next = NULL;
	while (q != NULL)
	{ 
		p->next = head->next;
		head->next= p;
		p= q;
		q = q->next;
	} 
	p->next = head->next;
	head->next= p;
} 
