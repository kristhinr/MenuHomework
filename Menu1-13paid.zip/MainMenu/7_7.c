#include<stdio.h>

int Getleft(int number){
	int i;
	for(i=0;i<5;i++)
		if(number%5 == 1 && number > 5){
			number=(number-1)*4/5;
			
		}
		else{
			return 0;
			break;
		}
		return 1;
}

int main(){
	int i;
	for(i=0; ;i++){
		if(Getleft(i)==1){
			printf("������%d��Ҭ��\n",i);
			break;
		}
	}
	printf("\n");
	return 0;
} 
